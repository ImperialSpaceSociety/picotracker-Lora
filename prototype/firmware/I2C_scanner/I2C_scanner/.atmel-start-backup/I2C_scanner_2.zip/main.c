#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	/* Initialise UART */
	
	struct io_descriptor *uart_io;
	usart_sync_get_io_descriptor(&USART_0, &uart_io);
	usart_sync_enable(&USART_0);
	
	/* Write Header */
	io_write(uart_io, (uint8_t *)"I2C Scanner\r\n", 13);
	
	/* Initialise I2C */
	
	struct io_descriptor *I2C_io;
	struct _i2c_m_msg msg;
	uint8_t	 reg;

	i2c_m_sync_get_io_descriptor(&I2C_0, &I2C_io);
	i2c_m_sync_enable(&I2C_0);
	
	msg.len    = 1;
	msg.flags  = I2C_M_STOP;
	msg.buffer = &reg;
	

	/* Replace with your application code */
	while (1) {
		uint8_t address;
		int16_t nDevices;
		int32_t error;

		io_write(uart_io, (uint8_t *)"Scanning...\r\n", 13);
		nDevices = 0;
		for(address = 8; address < 120; address++ )
		{
			msg.addr   = address;
			
			error = i2c_m_sync_transfer(&I2C_0, &msg);
			if (error == 0)
			{
				
				io_write(uart_io, (uint8_t *)"I2C device found at address 0x", 30);
				if (address<16)
				io_write(uart_io, (uint8_t *)"0", 1);
				io_write(uart_io, &address, 1);
				

				io_write(uart_io, (uint8_t *)"  !\r\n", 4);
				

				nDevices++;
			}
			
		}
		if (nDevices == 0)
		io_write(uart_io, (uint8_t *)"No I2C devices found\r\n\n", 23);
		else
		io_write(uart_io, (uint8_t *)"done\r\n\n", 7);
	
		delay_ms(5000); // wait 5 seconds for next scan
		
		
	}
}
