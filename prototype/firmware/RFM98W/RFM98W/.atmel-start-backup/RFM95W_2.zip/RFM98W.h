/*
 * Header File for RFM98W.
 *
 * 
 */
#ifndef RFM98W_INCLUDED
#define RFM98W_INCLUDED



/* Pinouts for prototype board on Atsamdl21 xplained */

#define RFM98W_DIO0_PIN		PB01
#define RFM98W_DIO1_PIN		PB30
#define RFM98W_DIO2_PIN		PA15
#define RFM98W_DIO3_PIN		PB10
#define RFM98W_DIO4_PIN		PB11
#define RFM98W_DIO5_PIN		PA16

#define RFM98W_CS_PIN		PA17
#define RFM98W_RESET_PIN	PB00



/* Function Prototypes */

void RFM98W_Init(void);
void Set_RFM98W_CS(uint8_t Value);
void reset_RFM98W(uint8_t value);
void write_RFM98W_Register(uint8_t reg, uint8_t val);
uint8_t read_RFM98W_Register(uint8_t reg);
void write_RFM98W_Raw(uint8_t * data, uint8_t length);
void set_RFM98W_DIO(uint8_t DIO);
uint8_t get_RFM98W_DIO(uint8_t DIO);
void configure_RFM98W_DIO(uint8_t DIO, uint8_t mode);
void reset_RFM98W(uint8_t value);


#endif
#endif // RFM98W_INCLUDED