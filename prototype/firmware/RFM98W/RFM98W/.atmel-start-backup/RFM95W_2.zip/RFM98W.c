/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */
#include "RFM98W.h"
#include <atmel_start.h>

struct io_descriptor *RFM98W_io;


/*
 * Drivers for RFM98W chip
 *
 * 
 */
#include "RFM98W.h"

/* set up the SPI Port and associated GPIO */
void RFM98W_Init(void)
{
	/* Configure Reset */
	gpio_set_pin_direction(RFM98W_RESET_PIN, GPIO_DIRECTION_OUT);
	gpio_set_pin_level(RFM98W_RESET_PIN, true);
	
	/* Configure Chip Select */
	gpio_set_pin_direction(RFM98W_CS_PIN, GPIO_DIRECTION_OUT);
	gpio_set_pin_level(RFM98W_CS_PIN, true);
	
	/* Configure DIO */
	gpio_set_pin_direction(RFM98W_DIO0_PIN, GPIO_DIRECTION_IN);
	gpio_set_pin_pull_mode(RFM98W_DIO0_PIN,	GPIO_PULL_UP);
	
	gpio_set_pin_direction(RFM98W_DIO1_PIN, GPIO_DIRECTION_IN);
	gpio_set_pin_pull_mode(RFM98W_DIO1_PIN,	GPIO_PULL_UP);
	
	gpio_set_pin_direction(RFM98W_DIO2_PIN, GPIO_DIRECTION_IN);
	gpio_set_pin_pull_mode(RFM98W_DIO2_PIN,	GPIO_PULL_UP);
	
	gpio_set_pin_direction(RFM98W_DIO3_PIN, GPIO_DIRECTION_IN);
	gpio_set_pin_pull_mode(RFM98W_DIO3_PIN,	GPIO_PULL_UP);
	
	gpio_set_pin_direction(RFM98W_DIO4_PIN, GPIO_DIRECTION_IN);
	gpio_set_pin_pull_mode(RFM98W_DIO4_PIN,	GPIO_PULL_UP);
	
	gpio_set_pin_direction(RFM98W_DIO5_PIN, GPIO_DIRECTION_IN);
	gpio_set_pin_pull_mode(RFM98W_DIO5_PIN,	GPIO_PULL_UP);

	spi_m_sync_get_io_descriptor(&SPI_0, &io);
	spi_m_sync_enable(&SPI_0);
}

/* Assert or clear SPI Chip Select 
 * 1 = select, 0 = de-select */

void Set_RFM98W_CS(int value)
{
	gpio_set_pin_level(RFM98W_CS_PIN, !value);
}

/* Hold SPI Chip Reset 
 * 1 = Reset, 0 = not Reset */
void reset_RFM98W(void)
{
	gpio_set_pin_level(RFM98W_RESET_PIN, false);
	delay_ms(1);
	gpio_set_pin_level(RFM98W_RESET_PIN, true);
}

/* Write to an RFM98W register */

void write_RFM98W_Register(uint8_t reg, uint8_t val)
{
	unsigned char data[2];
	
	data[0]= reg | 0x80;
	data[1] = val;

	Set_RFM98W_CS(true);
	
	io_write(RFM98W_io, data, 2);
	
	Set_RFM98W_CS(false);
}

/* Read from an RFM98W Register */

uint8_t read_RFM98W_Register(uint8_t reg)
{
	unsigned char data[2];
	uint8_t val;
	
	uint8_t	data = reg & 0x7F;
	uint8_t val;

	Set_RFM98W_CS(true);

	io_write(RFM98W_io, data, 1);
	io_read(RFM98W_io, data, 1);

	Set_RFM98W_CS(false);

	return val;
}


/* Direct write to RFM98W */

void write_RFM98W_Raw(uint8_t *data, uint8_t length)
{
	
	Set_RFM98W_CS(true);
	
	io_write(RFM98W_io, data, length);
	
	Set_RFM98W_CS(false);
}


/* Set value of DIO Pin */
void set_RFM98W_DIO(uint8_t DIO, uint8_t value)
{
	
	
	
}

/* Get value of DIO Pin */
uint8_t get_RFM98W_DIO(uint8_t DIO)
{
	
	
	
}

/* Configure mode of DIO Pin */

void configure_RFM98W_DIO(uint8_t DIO, uint8_t mode)
{
	
	
}

